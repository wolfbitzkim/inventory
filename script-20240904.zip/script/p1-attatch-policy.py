import boto3
import json
import sys

bucket_name = 'snow-cmd-output-1'

if len(sys.argv) != 3:
    print("Usage: python3 exec.py [role_name] [bucket_name]")
    exit(1)

# 머지할 역할 이름
# role_name = 'SnowRemoteWorkForInstancesRole'
role_name = sys.argv[1]
input_name = sys.argv[2]

if input_name != bucket_name:
    print(f"Error: The role name '{input_name}' does not match the bucket name '{bucket_name}'.")
    exit(1)

# AWS 세션 생성
profile_name = 'default'
region_name = 'ap-northeast-2'
session = boto3.Session(profile_name=profile_name, region_name=region_name)

# IAM 클라이언트 생성
iam_client = session.client('iam')

# 정책 추가
policy_name = 'SnowSSMSendCommand'
policy_document = {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Action": [
                "s3:PutObject",
                "s3:GetObject",
                "s3:PutObjectAcl"
            ],
            "Resource": [
                f"arn:aws:s3:::{bucket_name}/*"
            ],
            "Effect": "Allow",
            "Sid": "SnowPermissionsNeededForS3"
        },
        {
            "Action": [
                "ssm:DescribeAssociation",
                "ssm:GetDeployablePatchSnapshotForInstance",
                "ssm:GetDocument",
                "ssm:DescribeDocument",
                "ssm:GetManifest",
                "ssm:GetParameter",
                "ssm:GetParameters",
                "ssm:ListAssociations",
                "ssm:ListInstanceAssociations",
                "ssm:PutInventory",
                "ssm:PutComplianceItems",
                "ssm:PutConfigurePackageResult",
                "ssm:UpdateAssociationStatus",
                "ssm:UpdateInstanceAssociationStatus",
                "ssm:UpdateInstanceInformation",
                "ec2messages:AcknowledgeMessage",
                "ec2messages:DeleteMessage",
                "ec2messages:FailMessage",
                "ec2messages:GetEndpoint",
                "ec2messages:GetMessages",
                "ec2messages:SendReply"
            ],
            "Resource": "*",
            "Effect": "Allow",
            "Sid": "SnowPermissionsNeededForSSM"
        }
    ]
}

# 역할에 인라인 정책이 이미 존재하는지 확인
print(f"역할에 인라인 정책 '{policy_name}'이 이미 존재하는지 확인 중...")
inline_policies = iam_client.list_role_policies(RoleName=role_name)['PolicyNames']
if policy_name not in inline_policies:
    print(f"*** 정책이 존재하지 않음 추가할 정책 '{policy_name}' 내용")
    print(json.dumps(policy_document, indent=4))
    # exit(1)
    print(f"역할 '{role_name}' 에 정책 '{policy_name}' 추가 중...")
    iam_client.put_role_policy(
        RoleName=role_name,
        PolicyName=policy_name,
        PolicyDocument=json.dumps(policy_document)
    )
    print(f"정책 '{policy_name}'이 성공적으로 추가되었습니다.")
else:
    print(f"정책 '{policy_name}'이 이미 존재합니다. 추가하지 않았습니다.")
    print("정책 내용:")
    print(json.dumps(policy_document, indent=4))

# 현재 신뢰 관계 정책 가져오기
print("현재 신뢰 관계 정책 가져오는 중...")
response = iam_client.get_role(RoleName=role_name)
trust_policy = response['Role']['AssumeRolePolicyDocument']
print("현재 신뢰 관계 정책:")
print(json.dumps(trust_policy, indent=4))

# 새로운 신뢰 관계 정의
new_statement = {
    "Effect": "Allow",
    "Principal": {
        "Service": "ec2.amazonaws.com"
    },
    "Action": "sts:AssumeRole"
}

# 기존 신뢰 관계에 새로운 신뢰 관계가 이미 존재하는지 확인
print("기존 신뢰 관계에 새로운 신뢰 관계가 이미 존재하는지 확인 중...")
exists = any(
    statement.get("Effect") == new_statement["Effect"]and
    statement.get("Principal") == new_statement["Principal"]and
    statement.get("Action") == new_statement["Action"]
    for statement in trust_policy.get("Statement", [])
)

# 동일한 신뢰 관계가 존재하지 않는 경우에만 추가
if not exists:
    print("동일한 신뢰 관계가 존재하지 않습니다. 새로운 신뢰 관계 추가 중...")
    trust_policy['Statement'].append(new_statement)
    print("업데이트된 신뢰 관계 정책:")
    print(json.dumps(trust_policy, indent=4))

    # 신뢰 관계 정책 업데이트
    response = iam_client.update_assume_role_policy(
        RoleName=role_name,
        PolicyDocument=json.dumps(trust_policy)
    )
    print("정책 업데이트 응답:")
    print(response)

    # 업데이트된 신뢰 관계 정책 확인
    print("업데이트된 신뢰 관계 정책 확인 중...")
    updated_response = iam_client.get_role(RoleName=role_name)
    updated_trust_policy = updated_response['Role']['AssumeRolePolicyDocument']
    print("업데이트된 신뢰 관계 정책 확인:")
    print(json.dumps(updated_trust_policy, indent=4))
else:
    print("동일한 신뢰 관계가 이미 존재합니다. 추가하지 않았습니다.")
