#!/bin/bash
echo @ ap-northeast-2
aws ssm list-associations --region ap-northeast-2
echo @ us-east-1
aws ssm list-associations --region us-east-1