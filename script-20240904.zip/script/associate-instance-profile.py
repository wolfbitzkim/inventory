# - install boto3 library
# pip install boto3
# - execute
# python3 attatch-ec2-profile.py

import boto3

session = boto3.Session()
ec2_client = session.client('ec2')
iam_client = session.client('iam')

instance_profile_name = 'SnowAmazonSSMForInstancesProfile'
response = iam_client.get_instance_profile(InstanceProfileName=instance_profile_name)
instance_profile_arn = response['InstanceProfile']['Arn']

response = ec2_client.describe_instances()
instances = [instance for reservation in response['Reservations']for instance in reservation['Instances']]
for instance in instances:
    instance_id = instance['InstanceId']
    response = ec2_client.describe_iam_instance_profile_associations(
        Filters=[{'Name': 'instance-id', 'Values': [instance_id]}]
    )
    associations = response['IamInstanceProfileAssociations']

    if not associations:
        print(f'Attach {instance_profile_name} to instance {instance_id}')
        ec2_client.associate_iam_instance_profile(
            IamInstanceProfile={'Arn': instance_profile_arn},
            InstanceId=instance_id
        )
    else:
        print(f'Instance {instance_id} already instance profile attached. {associations}')
        #print(f'{associations}')

print('Script execution completed.')