import boto3
from botocore.exceptions import NoCredentialsError, PartialCredentialsError

def get_ec2_ami_info(profile_name, region_name):
    try:
        session = boto3.Session(profile_name=profile_name, region_name=region_name)
        ec2_client = session.client('ec2')

        instances = ec2_client.describe_instances()
        instance_ami_map = {}

        for reservation in instances['Reservations']:
            for instance in reservation['Instances']:
                instance_id = instance['InstanceId']
                ami_id = instance['ImageId']
                instance_ami_map[instance_id]= ami_id

        if not instance_ami_map:
            print("No instances found.")
            return []

        ami_info = ec2_client.describe_images(ImageIds=list(instance_ami_map.values()))

        ami_details = {}
        for image in ami_info['Images']:
            ami_details[image['ImageId']]= {
                'Name': image.get('Name', 'N/A'),
                'Description': image.get('Description', 'N/A'),
                'CreationDate': image['CreationDate']
            }

        result = []
        for instance_id, ami_id in instance_ami_map.items():
            ami_detail = ami_details.get(ami_id, {})
            result.append({
                'InstanceId': instance_id,
                'ImageId': ami_id,
                'Name': ami_detail.get('Name', 'N/A'),
                'Description': ami_detail.get('Description', 'N/A'),
                'CreationDate': ami_detail.get('CreationDate', 'N/A')
            })

        return result

    except NoCredentialsError:
        print("Credentials not available.")
        return []
    except PartialCredentialsError:
        print("Incomplete credentials provided.")
        return []
    except Exception as e:
        print(f"An error occurred: {e}")
        return []

if __name__ == "__main__":
    profile_name = 'default'
    region_name = 'ap-northeast-2'
    ami_details = get_ec2_ami_info(profile_name, region_name)
    for ami in ami_details:
        print(f"InstanceId: {ami['InstanceId']}, ImageId: {ami['ImageId']}, Name: {ami['Name']}, Description: {ami['Description']}, CreationDate: {ami['CreationDate']}")
        # print(f"{ami['InstanceId']} : {ami['Description']}, {ami['CreationDate']}")
