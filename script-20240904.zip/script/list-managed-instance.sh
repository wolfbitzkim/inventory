#!/bin/bash

# EC2 인스턴스 상태 조회
ec2_instances=$(aws ec2 describe-instances --query "Reservations[*].Instances[*].[InstanceId,State.Name,Tags,Platform,PlatformDetails]" --output json)

# SSM 관리 인스턴스 조회
ssm_instances=$(aws ssm describe-instance-information --query "InstanceInformationList[*].[InstanceId]" --output json)

# JSON 파싱을 위한 jq 설치 확인
if ! command -v jq &> /dev/null
then
    echo "jq가 설치되어 있지 않습니다. 설치 후 다시 시도하세요."
    exit
fi

# 카운터 초기화
total_instances=0
managed_by_ssm=0
not_managed_by_ssm=0
running_instances=0
stopped_instances=0

# 헤더 출력
printf "%-20s %-35s %-25s %-10s %-20s\n" "Instance ID" "Name" "OS Type" "State" "SSM Status"

# 결합된 결과 출력
for instance in $(echo "${ec2_instances}" | jq -r '.[][]| @base64'); do
    _jq() {
        echo ${instance} | base64 --decode | jq -r ${1}
    }
    instance_id=$(_jq '.[0]')
    state=$(_jq '.[1]')
    tags=$(_jq '.[2]')
    platform=$(_jq '.[3]')
    platform_details=$(_jq '.[4]')

    # 인스턴스 이름 추출
    name=$(echo "${tags}" | jq -r '.[]| select(.Key == "Name") | .Value')

    # 인스턴스 이름이 없는 경우 "N/A"로 설정
    if [ -z "${name}" ]; then
        name="N/A"
    fi

    # 운영 체제 타입 설정
    if [ -n "${platform}" ]&& [ "${platform}" != "null" ]; then
        os_type="${platform}"
    elif [ -n "${platform_details}" ]&& [ "${platform_details}" != "null" ]; then
        os_type="${platform_details}"
    else
        os_type="Linux/UNIX"
    fi

    # 총 인스턴스 수 증가
    total_instances=$((total_instances + 1))

    # 상태별 카운터 증가
    if [ "${state}" == "running" ]; then
        running_instances=$((running_instances + 1))
    elif [ "${state}" == "stopped" ]; then
        stopped_instances=$((stopped_instances + 1))
    fi

    if echo "${ssm_instances}" | jq -e ".[][]| select(. == \"${instance_id}\")" > /dev/null; then
        ssm_status="Managed by SSM"
        managed_by_ssm=$((managed_by_ssm + 1))
    else
        ssm_status="Not Managed"
        not_managed_by_ssm=$((not_managed_by_ssm + 1))
    fi

    # 정렬된 출력
    printf "%-20s %-35s %-15s %-10s %-20s\n" "${instance_id}" "${name}" "${os_type}" "${state}" "${ssm_status}"
done

# 총 인스턴스 수, SSM 관리 인스턴스 수, 관리되지 않는 인스턴스 수 출력
echo "Total Instances: ${total_instances}"
echo "Managed by SSM: ${managed_by_ssm}"
echo "Not Managed   : ${not_managed_by_ssm}"
echo "Running Instances: ${running_instances}"
echo "Stopped Instances: ${stopped_instances}"
